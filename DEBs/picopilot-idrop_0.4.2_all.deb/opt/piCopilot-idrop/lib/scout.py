import logging
import psycopg2
import re
import time
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from collections import OrderedDict
from lib.shared import Shared
from scapy.all import *

class Heartbeat(object):
    def __init__(self, parent):
        self.parent = parent

    def heartRhythm(self):
        """
        Create a seperate connection to the DB for heartbeat tracking
        """
        cStr = "dbname='ids' user='%s' host='%s' password='%s'" % (self.parent.unity.args.user, self.parent.unity.args.host, self.parent.cap.pWord)
        self.conBeat = psycopg2.connect(cStr)
        self.conBeat.autocommit = True
        self.dbBeat = self.conBeat.cursor()
        
        ## Backport to unity
        self.parent.unity.conBeat = self.conBeat

        ## Figure out if args.id has been seen before
        genQ = 'SELECT * FROM heartbeats WHERE idsid = %s;'
        self.dbBeat.execute(genQ, (self.parent.unity.args.id,))
        
        ## We've seen it, update
        if len(self.dbBeat.fetchall()) > 0:
            self.dbBeat.execute("UPDATE heartbeats SET idsid=%s,heartbeat=%s WHERE idsid=%s", (self.parent.unity.args.id, self.parent.cap.heartStamp(), self.parent.unity.args.id))

        ## Not seen til now
        else:
            qUp = 'INSERT INTO heartbeats(idsid, heartbeat) VALUES(%s, %s);'
            self.dbBeat.execute(qUp, (self.parent.unity.args.id, self.parent.cap.heartStamp()))
        
        ## Keep it updated at --beat intervals
        while True:
            self.dbBeat.execute("UPDATE heartbeats SET idsid=%s,heartbeat=%s WHERE idsid=%s", (self.parent.unity.args.id, self.parent.cap.heartStamp(), self.parent.unity.args.id))
            beat = self.parent.unity.args.beat
            if beat is None:
                time.sleep(60)
            else:
                time.sleep(int(beat))           ### unity.args later  



class Scout(object):
    """Parent class to handle all things LOTL from the scout perspective
    
    Built with the concept of being a child or parent
    
    Right now?  All we care about is Fortigate parsing, easy enough to flip
    """
    def __init__(self, dbInstance, unity, flatFile = True):
        if unity.args.z is True:
            print ('scout.Scout instantiated')
        self.cap = dbInstance
        self.unity = unity
        self.packetCount = 0
        self.tupleSet = set()
        self.unity.tupleSet = self.tupleSet
        self.flatFile = flatFile
        self.sh = Shared()

        ## Setup tables

        ## SQLite Usage
        x = ['ids',
             'dhcpreq',
             'dhcpack']
        if self.unity.args.psql is not True:
            for i in x:
                
                ### Look into tupling on the inner ()
                self.cap.db.execute("""
                                    CREATE TABLE IF NOT EXISTS {0}(idsid TEXT,
                                                                   epoch INTEGER,
                                                                   date TEXT,
                                                                   time TEXT,
                                                                   logdate TEXT,
                                                                   logtime TEXT,
                                                                   srcname TEXT,
                                                                   srcmac TEXT,
                                                                   srcoui TEXT,
                                                                   srcip TEXT,
                                                                   dstip TEXT,
                                                                   srcport INTEGER,
                                                                   dstport INTEGER,
                                                                   srcintf TEXT,
                                                                   dstintf TEXT,
                                                                   app TEXT);
                                    """.format(i))

        ## PSQL usage
        else:
            for i in x:
                self.cap.db.execute("""
                                    CREATE TABLE IF NOT EXISTS {0}(idsid TEXT,
                                                                   pi_epoch INT,
                                                                   pi_timestamp TIMESTAMPTZ,
                                                                   log_timestamp TIMESTAMPTZ,
                                                                   srcname TEXT,
                                                                   srcmac TEXT,
                                                                   srcoui TEXT,
                                                                   srcip TEXT,
                                                                   dstip TEXT,
                                                                   srcport INT,
                                                                   dstport INT,
                                                                   srcintf TEXT,
                                                                   dstintf TEXT,
                                                                   app TEXT);
                                    """.format(i))
            self.cap.db.execute("""
                                CREATE TABLE IF NOT EXISTS heartbeats(idsid TEXT,
                                                               heartbeat TEXT);
                                """)


        ## Deal with PCAP storage
        if self.unity.args.pcap:
            tStamp = time.strftime('%Y%m%d_%H%M', time.localtime()) + '.pcap'
            pLog = self.cap.dDir + '/' + tStamp
            self.pStore = PcapWriter(pLog, sync = True)
        else:
            self.pStore = False
        
        ## Reorder this for visual later
        self.fields = {'srcip': '',
                       'srcname': '"',
                       'srcintf': '"',
                       'srcport': '',
                       'dstip': '',
                       'dstintf': '',
                       'dstport': '',
                       'app': '"',
                       'date': '',
                       'srcmac': '"',
                       'time': ''}


        self.idsRecords = ['date',
                           'time',
                           'srcname',
                           'srcmac',
                           'srcip',
                           'dstip',
                           'srcport',
                           'dstport',
                           'srcintf',
                           'dstintf',
                           'app']

        ## Pull prior discoveries so that we don't re-discover already found
        if self.unity.args.recover is True:
            idsLocation = self.unity.args.id.split('_')[0] + '_%'
            qry = "SELECT srcname, srcip, srcmac, srcintf FROM ids WHERE idsid LIKE %s;"
            self.cap.db.execute(qry, (idsLocation,))
            for i in self.cap.db.fetchall():
                self.tupleSet.add(i)
            qry = "SELECT srcname, srcip, srcmac, srcintf FROM dhcpreq WHERE idsid LIKE %s;"
            self.cap.db.execute(qry, (idsLocation,))
            for i in self.cap.db.fetchall():
                self.tupleSet.add(i)
            qry = "SELECT srcname, srcip, srcmac, srcintf FROM dhcpack WHERE idsid LIKE %s;"
            self.cap.db.execute(qry, (idsLocation,))
            for i in self.cap.db.fetchall():
                self.tupleSet.add(i)

        ## Setup heartbeat
        self.hb = Heartbeat(self)
        


    def idsLITEDBupdate(self):
        """Update the SQL database"""
        try:
            self.srcOui = self.unity.ouiDict.get(self.ourRecord.get('srcmac')[0:8])
        except:
            self.srcOui = None
        self.unity.times()
        self.cap.db.execute("""
                            INSERT INTO ids VALUES(?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?,
                                                    ?);
                            """,
                                (self.unity.args.id,
                                 self.unity.logDict.get('total'),
                                 self.unity.epoch,
                                 self.unity.lDate,
                                 self.unity.lTime,
                                 self.ourRecord.get('date'),
                                 self.ourRecord.get('time'),
                                 self.ourRecord.get('srcname'),
                                 self.ourRecord.get('srcmac'),
                                 self.srcOui,
                                 self.ourRecord.get('srcip'),
                                 self.ourRecord.get('dstip'),
                                 self.ourRecord.get('srcport'),
                                 self.ourRecord.get('dstport'),
                                 self.ourRecord.get('srcintf'),
                                 self.ourRecord.get('dstintf'),
                                 self.ourRecord.get('app')))


    def idsPSQLupdate(self, db):
        """Update the PGSQL database"""
        try:
            self.srcOui = self.unity.ouiDict.get(self.ourRecord.get('srcmac')[0:8])
        except:
            self.srcOui = None
        self.unity.times()
        self.cap.db.execute("""
                            INSERT INTO {0} (idsid,
                                             pi_epoch,
                                             pi_timestamp,
                                             log_timestamp,
                                             srcname,
                                             srcmac,
                                             srcoui,
                                             srcip,
                                             dstip,
                                             srcport,
                                             dstport,
                                             srcintf,
                                             dstintf,
                                             app)
                                        VALUES (%s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s,
                                                %s);
                            """.format(db),
                                (self.unity.args.id,
                                 self.unity.epoch,
                                 str(self.unity.lDate) + ' ' + str(self.unity.lTime) + '-05',
                                 str(self.ourRecord.get('date')) + ' ' + str(self.ourRecord.get('time')) + '-05',
                                 self.ourRecord.get('srcname'),
                                 self.ourRecord.get('srcmac'),
                                 self.srcOui,
                                 self.ourRecord.get('srcip'),
                                 self.ourRecord.get('dstip'),
                                 self.ourRecord.get('srcport'),
                                 self.ourRecord.get('dstport'),
                                 self.ourRecord.get('srcintf'),
                                 self.ourRecord.get('dstintf'),
                                 self.ourRecord.get('app')))


    def liveSniff(self):
        """liveSniff uses this
        
        This is memory constrained as we host the distincts on client, not server
        
        Our timedeltas will tell us much.
        """
        def snarf(pkt):
            ourRecord = OrderedDict()
        
            ## Only what we care about IDS wise          
            for field in self.idsRecords:
        
                ourGrab = re.findall('{1}={0}(.*?)[{0}| ]'.format(self.fields.get(field), field), str(pkt[Raw].load)) ## << Class this, or it becomes expensive
                if len(ourGrab) > 0:
                    ourRecord.update({field: ourGrab[0].strip('"')})
                else:
                    ourRecord.update({field: None})
            
            ## Update the tuple
            ## MINI concept
            ourTuple = (ourRecord.get('srcname'),
                        ourRecord.get('srcip'),
                        ourRecord.get('srcmac'),
                        ourRecord.get('srcintf'))
            
            ## Prep for updating record if not seen in tupleSet && no None
            if ourTuple not in self.tupleSet and None not in ourTuple:
                            
                ## Set db table type
                aType = None
                
                ## DHCP Request
                if ourTuple[1] == '0.0.0.0' and ourRecord.get('app') == 'DHCP/DHCP':
                    aType = 'dhcpreq'
                
                ## DHCP ACK
                elif ourRecord['dstip'] == '255.255.255.255' and ourRecord.get('app') == 'DHCP/DHCP':
                    aType = 'dhcpack'
                
                ## Non-DHCP traffic
                ## Disregard Fortigate unknown0 interface -- https://kb.fortinet.com/kb/documentLink.do?externalID=FD46048
                elif ourRecord.get('srcintf') != 'unknown0' and ourRecord.get('dstintf') != 'unknown0':
                    aType = 'ids'
                    
                ## Fire to SQL here
                if aType is not None:
                    try:
                        self.ourRecord = ourRecord
                        if self.unity.args.psql is False:
                            self.idsLITEDBupdate()
                        else:
                            self.idsPSQLupdate(aType)

                        ## Update IDS count
                        self.unity.logUpdate('ids')
                    except Exception as E:
                        print (E)
    
    
                    ## Notate to flatfile
                    if self.flatFile is True:
                        logEntry = 'date={0} '.format(ourRecord.get('date'))
                        logEntry += 'time={0} '.format(ourRecord.get('time'))
                        logEntry += 'idsid={0} '.format(self.unity.args.id)
                        logEntry += 'srcname={0} '.format(ourRecord.get('srcname'))
                        logEntry += 'srcmac={0} '.format(ourRecord.get('srcmac'))
                        logEntry += 'srcip={0} '.format(ourRecord.get('srcip'))
                        logEntry += 'dstip={0} '.format(ourRecord.get('dstip'))
                        logEntry += 'srcport={0} '.format(ourRecord.get('srcport'))
                        logEntry += 'dstport={0} '.format(ourRecord.get('dstport'))
                        logEntry += 'srcintf={0} '.format(ourRecord.get('srcintf'))
                        logEntry += 'dstintf={0} '.format(ourRecord.get('dstintf'))
                        logEntry += 'app={0} '.format(ourRecord.get('app'))
                        logEntry += 'srcoui={0}'.format(self.srcOui)
                        with open(self.unity.baseDir + '/ids.log', 'a') as oFile:
                            oFile.write(logEntry + '\n')
    
                    ## Notate to memory
                    self.tupleSet.add(ourTuple)
            
        return snarf


    def DEBUG(self, count):
        """Debugging mode"""
        def snarf(pkt):
            ourRecord = OrderedDict()
        
            ## Only what we care about IDS wise          
            for field in self.idsRecords:
        
                ourGrab = re.findall('{1}={0}(.*?)[{0}| ]'.format(self.fields.get(field), field), str(pkt[Raw].load)) ## << Class this, or it becomes expensive
                if len(ourGrab) > 0:
                    ourRecord.update({field: ourGrab[0].strip('"')})
                else:
                    ourRecord.update({field: None})
            
            ## Update the tuple
            ## MINI concept
            ourTuple = (ourRecord.get('srcname'),
                        ourRecord.get('srcip'),
                        ourRecord.get('srcmac'),
                        ourRecord.get('srcintf'))
            
            ## Prep for updating record if not seen in tupleSet && no None
            if ourTuple not in self.tupleSet and ourTuple.count(None) >= int(count):
                            
                ## Set db table type
                aType = None
                
                ## DHCP Request
                if ourTuple[1] == '0.0.0.0' and ourRecord.get('app') == 'DHCP/DHCP':
                    aType = 'dhcpreq'
                
                ## DHCP ACK
                elif ourRecord['dstip'] == '255.255.255.255' and ourRecord.get('app') == 'DHCP/DHCP':
                    aType = 'dhcpack'
                
                ## Non-DHCP traffic
                ## Disregard Fortigate unknown0 interface -- https://kb.fortinet.com/kb/documentLink.do?externalID=FD46048
                elif ourRecord.get('srcintf') != 'unknown0' and ourRecord.get('dstintf') != 'unknown0':
                    aType = 'ids'
                    
                ## Fire to SQL here
                if  aType is not None:
                    try:
                        self.ourRecord = ourRecord
                        if self.unity.args.psql is False:
                            self.idsLITEDBupdate()
                        else:
                            self.idsPSQLupdate(aType)

                        ## Update IDS count
                        self.unity.logUpdate('ids')
                    except Exception as E:
                        print (E)
    
    
                    ## Notate to flatfile
                    if self.flatFile is True:
                        logEntry = 'date={0} '.format(ourRecord.get('date'))
                        logEntry += 'time={0} '.format(ourRecord.get('time'))
                        logEntry += 'idsid={0} '.format(self.unity.args.id)
                        logEntry += 'srcname={0} '.format(ourRecord.get('srcname'))
                        logEntry += 'srcmac={0} '.format(ourRecord.get('srcmac'))
                        logEntry += 'srcip={0} '.format(ourRecord.get('srcip'))
                        logEntry += 'dstip={0} '.format(ourRecord.get('dstip'))
                        logEntry += 'srcport={0} '.format(ourRecord.get('srcport'))
                        logEntry += 'dstport={0} '.format(ourRecord.get('dstport'))
                        logEntry += 'srcintf={0} '.format(ourRecord.get('srcintf'))
                        logEntry += 'dstintf={0} '.format(ourRecord.get('dstintf'))
                        logEntry += 'app={0} '.format(ourRecord.get('app'))
                        logEntry += 'srcoui={0}'.format(self.srcOui)
                        with open(self.unity.baseDir + '/ids.log', 'a') as oFile:
                            oFile.write(logEntry + '\n')
    
                    ## Notate to memory
                    self.tupleSet.add(ourTuple)
                    print(ourTuple)
            
        return snarf
