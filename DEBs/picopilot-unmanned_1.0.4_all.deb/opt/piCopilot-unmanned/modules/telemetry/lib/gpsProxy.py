#!/usr/bin/python2

from pymavlink import mavutil
import time
import zmq

from MAVProxy.modules.lib import mp_module
from MAVProxy.modules.lib import mp_util
from MAVProxy.modules.lib import mp_settings

class GPSproxy(mp_module.MPModule):
    def __init__(self, mpstate):
        super(GPSproxy, self).__init__(mpstate, "GPSproxy", "")

        ## Setup the Telemetry IPC -- TX
        context = zmq.Context()
        self.telem_IPC = context.socket(zmq.PAIR)
        self.telem_IPC.connect('tcp://127.0.0.1:5556')

        ## Setup our intervals
        self.checkInterval = .8
        self.lastCheck = time.time()

        ## Set the proxy
        self.verbose = False
        self.GPSproxy_settings = mp_settings.MPSettings([('verbose',
                                                          bool,
                                                          False),])


    def idle_task(self):
        """called rapidly by mavproxy"""
        if time.time() - self.lastCheck > self.checkInterval:
            self.lastCheck = time.time()
            gpsStatus = self.mpstate.status.msgs['GLOBAL_POSITION_INT']
            timeStatus = self.mpstate.status.msgs['SYSTEM_TIME']
            telemDict = gpsStatus.to_dict()
            timeDict = timeStatus.to_dict()
            telemDict.update({'time_unix_usec': timeDict.get('time_unix_usec')})
            self.telem_IPC.send_pyobj(telemDict)


def init(mpstate):
    """initialise the proxy module"""
    return GPSproxy(mpstate)
